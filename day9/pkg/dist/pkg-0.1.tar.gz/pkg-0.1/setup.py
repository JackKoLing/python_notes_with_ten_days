"this file use to setup python release."

from distutils.core import setup

setup(
    name='pkg',
    version='0.1',
    description='use to setup python release',
    author='jackko',
    author_email='1219174482@qq.com',
    py_modules=['new_module'],

)